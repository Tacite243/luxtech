-- AlterTable
ALTER TABLE "Product" ADD COLUMN     "rating" INTEGER NOT NULL DEFAULT 0;
