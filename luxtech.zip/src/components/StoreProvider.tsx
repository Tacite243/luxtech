'use client';

import { useRef } from 'react';
import { Provider } from 'react-redux';
import { makeStore, AppStore } from '../redux/store';
import { injectStore } from '@/lib/axiosInstance';



export default function StoreProvider({
    children,
}: {
    children: React.ReactNode;
}) {
    const storeRef = useRef<AppStore | null>(null);

    if (!storeRef.current) {
        storeRef.current = makeStore();
        injectStore(storeRef.current);
        storeRef.current.subscribe(() => {
            try {
                const state = storeRef.current!.getState();
                const serializedState = JSON.stringify(state.cart.items);
                localStorage.setItem('cart', serializedState);
            } catch (err) {
                // Ignorer les erreurs d'écriture
            }
        })
    }

    return <Provider store={storeRef.current}>{children}</Provider>;
}